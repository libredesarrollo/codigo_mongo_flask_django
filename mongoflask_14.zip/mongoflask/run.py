from proyect_app import app

app.run()