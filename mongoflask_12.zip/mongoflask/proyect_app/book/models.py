import mongoengine as models
from flask_mongoengine import BaseQuerySet
from flask_mongoengine.wtf import model_form

class Book(models.Document):
    _id = models.ObjectIdField()
    name = models.StringField(required=True, max_length=255)
    content = models.StringField(required=True)

    meta = { 'queryset_class' : BaseQuerySet }

    def __str__(self):
        return self.name

    def setByForm(self, form):
        self.name = form.name.data
        self.content = form.content.data

BookForm = model_form(Book)