import { createApp } from 'vue'
import App from './App.vue'

const bootstrap = require('bootstrap')
bootstrap
createApp(App).mount('#app')
