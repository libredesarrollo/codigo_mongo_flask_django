from flask import Flask
from flask_mongoengine import MongoEngine

app = Flask(__name__)

app.config['MONGODB_SETTINGS'] ={
    'db' : 'mongoflask'
}

app.config['SECRET_KEY'] = "4545a4s5a4s15a4s5a4s541"

app.debug = True

db = MongoEngine(app)

#controladores
from proyect_app.book.controllers import bookBp
app.register_blueprint(bookBp)
