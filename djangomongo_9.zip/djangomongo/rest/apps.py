from django.apps import AppConfig


class RestConfig(AppConfig):
    name = 'rest'
