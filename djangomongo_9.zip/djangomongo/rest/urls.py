from rest_framework import routers

from .viewsets import BookViewset, CategoryViewset, TagViewset

route = routers.SimpleRouter()

route.register('book',BookViewset)
route.register('category',CategoryViewset)
route.register('tag',TagViewset)

urlpatterns = route.urls