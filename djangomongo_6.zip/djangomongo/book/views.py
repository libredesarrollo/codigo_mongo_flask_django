from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.http import JsonResponse

from bson.objectid import ObjectId

from .models import Book
from .forms import BookForm

# Create your views here.

def index(request):
    return _listBook(request, BookForm())

def add(request):

    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
        else:
            return _listBook(request, form)

    return redirect('book:index')

def update(request, pk):

    book = Book.objects.get(pk=ObjectId(pk))

    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
        else:
            return _listBook(request, form)

    return redirect('book:index')

def delete(request,pk):

    try:
        book = Book.objects.get(pk=ObjectId(pk))
        book.delete()
    except Book.DoesNotExist:
        pass

    return redirect('book:index')

#-------- privados

def _listBook(request, form):
    books = Book.objects.all()
    paginator = Paginator(books,2)

    page_number = request.GET.get('page')
    books_page = paginator.get_page(page_number)
    
    return render(request, 'book/index.html',{'books':books_page, 'form': form})


#-------- json
def jgetBookById(request,pk):

    try:
        book = Book.objects.get(pk=ObjectId(pk))
    except Book.DoesNotExist:
        return JsonResponse("")

    return JsonResponse({
        'name': book.name,
        'content': book.content,
    })